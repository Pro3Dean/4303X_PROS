#include "main.h"

bool intake_ON = true;

pros::Controller master(pros::E_CONTROLLER_MASTER);
	
pros::Motor FrontLeft (18, true);
pros::Motor MiddleLeft (14, true);
pros::Motor BackLeft (13, true);
pros::Motor_Group LeftDrive6 ({18, 14, 13});
pros::Motor_Group LeftDrive4 ({18, 13});

pros::Motor FrontRight (7, false);
pros::Motor MiddleRight (9, false);
pros::Motor BackRight (15, false);
pros::Motor_Group RightDrive6 ({7, 9, 15});
pros::Motor_Group RightDrive4 ({7, 15}); 

pros::Motor LeftIntake (14, true);
pros::Motor RightIntake (9, false);
pros::Motor_Group Intake ({14, 9});

pros::Motor TopFlywheel (10, false);
pros::Motor BotFlywheel (4, true);
pros::Motor_Group Flywheel ({10, 4});

pros::ADIDigitalOut PTO (1, false);
pros::ADIDigitalOut Actuator (2, false);
pros::ADIDigitalOut Endgame (3, false);

pros::Imu Inertial (1);

#include "main.h"

void gyroPID(double targetAngle, bool drive4 = false, double turnKP = 0.98, double turnKD = 0/*5.5*/){
  Inertial.tare_rotation();
  if(drive4 == true){
    PTO.set_value(false);
    pros::delay(250);
    double threshold = 1;
    /*if(targetAngle <- 0.0){
      threshold = 1.5;
    }
    else{
      threshold = 0.7;
    }*/

    double error = targetAngle - (Inertial.get_rotation()+14.525);
    double derivative;
    double prevError;

    while(fabs(error) > threshold){
      error = targetAngle - (Inertial.get_rotation()+14.525);

      derivative = error - prevError;
      prevError = error;
      double p = error * turnKP;
      double d = derivative * turnKD;

      double vel = p + d;

      FrontLeft.move_velocity(vel);
      FrontRight.move_velocity(-vel);
      BackLeft.move_velocity(vel);
      BackRight.move_velocity(-vel);

      pros::delay(15);
    }
    FrontLeft.move(0);
    FrontRight.move(0);
    BackLeft.move(0);
    BackRight.move(0);
  }else if(drive4 == false){
    PTO.set_value(true);
    pros::delay(250);
    double threshold = 1;
    /*if(targetAngle <- 0.0){
      threshold = 1.5;
    }
    else{
      threshold = 0.7;
    }*/

    double error = targetAngle - (Inertial.get_rotation()+14.525);
    double derivative;
    double prevError;

    while(fabs(error) > threshold){
      error = targetAngle - (Inertial.get_rotation()+14.525);

      derivative = error - prevError;
      prevError = error;
      double p = error * turnKP;
      double d = derivative * turnKD;

      double vel = p + d;

      FrontLeft.move_velocity(vel);
      FrontRight.move_velocity(-vel);
      MiddleLeft.move_velocity(vel);
      MiddleRight.move_velocity(-vel);
      BackLeft.move_velocity(vel);
      BackRight.move_velocity(-vel);

      pros::delay(15);
    }
    FrontLeft.move(0);
    FrontRight.move(0);
    MiddleLeft.move(0);
    MiddleRight.move(0);
    BackLeft.move(0);
    BackRight.move(0);
  }
}

void drivePID(double target, bool drive4 = false, bool driveIntake = false, double kP = 1.4, double kD = 0/*5.5*/){
  if(drive4 == true){
    PTO.set_value(false);
	LeftDrive4.tare_position();
	RightDrive4.tare_position();
	pros::delay(250);
    double error = 0;
    double prevError;

    double threshold = 1;
    /*if(target <- 0.0){
      threshold = 1.5;
    }else{
      threshold = 0.7;
    }*/
    double averagePosition = (FrontLeft.get_position() + FrontRight.get_position())/2 * 10.21*360;
    error = averagePosition - target;
    double derivative;
    prevError = 0;

    
    while(fabs(error) > threshold){
      if(driveIntake == true){
        Intake.move_velocity(200);
      }else{
        Intake.move(0);
      }
      averagePosition = (FrontLeft.get_position() + FrontRight.get_position())/2 * 10.21*360;
      error = averagePosition - target;

      derivative = error - prevError;
      prevError = error;
      double p = error * kP;
      double d = derivative * kD;

      double vel = p + d;

      FrontLeft.move_velocity(vel);
      FrontRight.move_velocity(vel);
      BackLeft.move_velocity(vel);
      BackRight.move_velocity(vel);

      pros::delay(15);
    }
    FrontLeft.move(0);
    FrontRight.move(0);
    BackLeft.move(0);
    BackRight.move(0);
    Intake.move(0);
  }else if(drive4 == false && driveIntake == false){
    PTO.set_value(true);
    double error = 0;
    double prevError;
	RightDrive6.tare_position();
	LeftDrive6.tare_position();
	pros::delay(250);

    double threshold = 1;
    /*if(target <- 0.0){
      threshold = 1.5;
    }else{
      threshold = 0.7;
    }*/
    double averagePosition = (FrontLeft.get_position() + FrontRight.get_position())/2 * 10.21*360;
    error = averagePosition - target;
    double derivative;
    prevError = 0;

    
    while(fabs(error) > threshold){
      averagePosition = (FrontLeft.get_position() + FrontRight.get_position())/2 * 10.21*360;
      error = averagePosition - target;

      derivative = error - prevError;
      prevError = error;
      double p = error * kP;
      double d = derivative * kD;

      double vel = p + d;

      FrontLeft.move_velocity(vel);
      FrontRight.move_velocity(vel);
      MiddleLeft.move_velocity(vel);
      MiddleRight.move_velocity(vel);
      BackLeft.move_velocity(vel);
      BackRight.move_velocity(vel);

      pros::delay(15);
    }
    FrontLeft.move(0);
    FrontRight.move(0);
    MiddleLeft.move(0);
    MiddleRight.move(0);
    BackLeft.move(0);
    BackRight.move(0);
    Intake.move(0);
  }
}
/*
void driveIt(float inches, bool drive4 = false, bool intakeWhileDrive = false){
  if(drive4 == false){
    PTO.set(true);
    FrontLeft.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    MiddleLeft.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    BackLeft.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    FrontRight.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    MiddleRight.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    BackRight.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, true);
  }else if(drive4 == true){
    PTO.set(false);
    if(intakeWhileDrive == true){
      Intake.spin(directionType::fwd);
    }else{
      Intake.stop();
    }
    FrontLeft.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    BackLeft.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    FrontRight.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, false);
    BackRight.spinFor(directionType::fwd, inches/(3.25*3.14159), rotationUnits::rev, true);
    Intake.stop();
  }
}*/
/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");
  	master.clear();
  	master.set_text(1, 1, "Calibration: In Progress...");
	Inertial.reset();
  	pros::Task::delay(2000);
	master.clear();
  	master.set_text(1, 1, "Calibration: Done!");
	master.rumble(". - - - .");

	Flywheel.set_brake_modes(MOTOR_BRAKE_COAST);
	Intake.set_brake_modes(MOTOR_BRAKE_BRAKE);
	RightDrive4.set_brake_modes(MOTOR_BRAKE_HOLD);
	LeftDrive4.set_brake_modes(MOTOR_BRAKE_HOLD);
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {
  RightDrive4.brake();
  LeftDrive4.brake();
}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {
	RightDrive6.move(-50);			//Drive into wall, getting relative position to roller
	LeftDrive6.move(-50);
	pros::delay(1500);
	RightDrive6.brake();
	LeftDrive6.brake();
	drivePID(20);					//Drive 20 inches from wall
	pros::delay(100);
	gyroPID(90);
	pros::delay(100);
	drivePID(24);					//Drive towards the roller
	pros::delay(100);
	gyroPID(-90);
	pros::delay(100);
	drivePID(-18, true);			//Drive into roller in 4 motor drive
	pros::delay(100);
	Intake.move(-100);				//spin intake-roller
	pros::delay(250);
	Intake.brake();
	drivePID(18);					//Drive away
}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {

	while (true) {
		while(intake_ON == false){
			PTO.set_value(true);
			LeftDrive6.move(master.get_analog(ANALOG_LEFT_Y));
			RightDrive6.move(master.get_analog(ANALOG_RIGHT_Y));
			
			if(master.get_digital(DIGITAL_X)){
				PTO.set_value(false);
				intake_ON = true;
			}

			if(master.get_digital(DIGITAL_L1)){
				Flywheel.move_voltage(86);
			}else{
				Flywheel.brake();
			}

			if(master.get_digital(DIGITAL_R1)){
				Actuator.set_value(true);
			}else{
				Actuator.set_value(false);
			}

			if(master.get_digital(DIGITAL_L2) && master.get_digital(DIGITAL_L2)){
				Endgame.set_value(true);
			}
		}while(intake_ON == true){
			PTO.set_value(false);
			LeftDrive4.move(master.get_analog(ANALOG_LEFT_Y));
			RightDrive4.move(master.get_analog(ANALOG_RIGHT_Y));

			if(master.get_digital(DIGITAL_DOWN)){
				Intake.move(100);
			}else if(master.get_digital(DIGITAL_UP)){
				Intake.move(-200);
			}else if(master.get_digital(DIGITAL_RIGHT)){
				Intake.move(-50);
			}else{
				Intake.move(0);
			}
			if(master.get_digital(DIGITAL_B)){
				PTO.set_value(true);
				intake_ON = false;
			}

			if(master.get_digital(DIGITAL_L1)){
				Flywheel.move_voltage(86);
			}else{
				Flywheel.brake();
			}

			if(master.get_digital(DIGITAL_R1)){
				Actuator.set_value(true);
			}else{
				Actuator.set_value(false);
			}

			if(master.get_digital(DIGITAL_L2) && master.get_digital(DIGITAL_L2)){
				Endgame.set_value(true);
			}
		}
		pros::delay(20);
	}
}
