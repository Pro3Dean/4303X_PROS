#include "main.h"

//Front of Roller
void RollerSide(){
    spinFlywheel(115);     //start spinning flywheel at 2500 rpm
    setDrive(-60, -60);     //drive to roller for 500 milliseconds
    pros::delay(500);
    setDrive(0, 0);     //briefly stop for 1.5 seconds
    pros::delay(1500);
    Intake.move_relative(0.3, pros::E_MOTOR_ENCODER_ROTATIONS);     //spin the roller 0.3 rotations, causing the roller to flip to our team
    pros::delay(1000);
    driving(2.5, 80, false);   //drive 2.5 inches at 67% velocity (80 volts) towards the goal
    pros::delay(250);
    turning(-12.75, 40);    //turn towards the goal at 33% velocity (40 volts)
    pros::delay(750);
    indexerShoot(3);    //after 750 milliseconds, shoot 3 times. 2 discs are in the robot, but the 3rd is to guarantee all discs were shot
    pros::delay(250);
    stopFlywheel;   //stop the flywheel
}

void RollerSideAWP(){
    spinFlywheel(115);       //start spinning flywheel at 2500 rpm
    setDrive(-60, -60);     //drive to roller for 500 milliseconds
    pros::delay(500);
    setDrive(0, 0);     //briefly stop for 1.5 seconds
    pros::delay(1500);
    Intake.move_relative(0.3, pros::E_MOTOR_ENCODER_ROTATIONS);     //spin the roller 0.3 rotations, causing the roller to flip to our team
    pros::delay(1000);
    driving(2.5, 80, false);   //drive 2.5 inches at 67% velocity (80 volts) towards the goal
    pros::delay(250);
    turning(-12.75, 40);    //turn towards the goal at 33% velocity (40 volts)
    pros::delay(750);
    indexerShoot(3);        //after 750 milliseconds, shoot 3 times. 2 discs are in the robot, but the 3rd is to guarantee all discs were shot
    pros::delay(250);
    stopFlywheel;   //stop the flywheel
    pros::delay(500);
    turning(-90-45+12.75, 40);  //turn towards stack of discs at 33% velocity (40 volts)
    pros::delay(250);
    Intake = -100;     
    driving(-24, 100, false);  //drive towards the stack of discs while outtaking. This causes the stack of discs to fall down, making intaking more reliable
    pros::delay(500);
    driving(-15, 100, true);    //drive 15 inches, intaking all 3 discs
    pros::delay(250);
    Intake = 120;       //spin intake for 750 milliseconds
    pros::delay(750);
    Intake = 0;
    spinFlywheel(115);
    turning(95, 40);    //turn towards goal at 33% velocity (40 volts); spin the flywheel at 2375 rpm
    pros::delay(3000);
    Intake = 0;
    indexerShoot(4);    //after 3 seconds, shoot 4 times. 3 discs are in the robot, but the 4th is to guarantee all discs were shot
    pros::delay(250);
    stopFlywheel;   //stop the flywheel
}

//Next To Tape
void TapeSide(){
    spinFlywheel;
    driving(3.75, 60, false);
    pros::delay(250);
    turning(90, 40);
    pros::delay(500);
    driving(14, 50, false);
    pros::delay(250);
    turning(-90, 40);
    pros::delay(500);
    setDrive(-60, -60);
    pros::delay(500);
    setDrive(0, 0);
    pros::delay(1500);
    Intake.move_relative(0.425, pros::E_MOTOR_ENCODER_ROTATIONS);
    pros::delay(1500);
    driving(4, 50, false);
    pros::delay(3000);
    indexerShoot(3);
    pros::delay(250);
    stopFlywheel;
}

void TapeSideAWP(){
    spinFlywheel;
    driving(3.75, 60, false);
    pros::delay(250);
    turning(90, 40);
    pros::delay(500);
    driving(14, 50, false);
    pros::delay(250);
    turning(-90, 40);
    pros::delay(500);
    setDrive(-60, -60);
    pros::delay(500);
    setDrive(0, 0);
    pros::delay(1500);
    Intake.move_relative(0.425, pros::E_MOTOR_ENCODER_ROTATIONS);
    pros::delay(1500);
    driving(4, 50, false);
    pros::delay(3000);
    indexerShoot(3);
    pros::delay(250);
    stopFlywheel;
    turning(90, 40);
    pros::delay(250);
    driving(-12, 60, false);
    pros::delay(250);
    turning(45, 40);
    pros::delay(250);
    driving(-30, 60, true);
    pros::delay(1000);
    Intake = 127;
    turning(-90, 40);
    pros::delay(1000);
    Intake = 0;
    spinFlywheel(2375);
    pros::delay(3000);
    indexerShoot(4);
    pros::delay(250);
    stopFlywheel;
}

//Skills
void RollerSideEndgame(){
    spinFlywheel(2000);
    setDrive(-60, -60);
    pros::delay(500);
    setDrive(0, 0);
    pros::delay(1500);
    Intake.move_relative(0.4, pros::E_MOTOR_ENCODER_ROTATIONS);
    pros::delay(1500);
    driving(5, 40, true);
    pros::delay(250);
    turning(90+45, 80);
    pros::delay(250);
    driving(-5.5, 80, true);
    pros::delay(250);
    turning(-45, 80);
    pros::delay(250);
    setDrive(-60, -60);
    pros::delay(1000);
    setDrive(0, 0);
    pros::delay(1500);
    Intake.move_relative(0.4, pros::E_MOTOR_ENCODER_ROTATIONS);
    pros::delay(1500);
    driving(6, 80, false);
    pros::delay(250);
    turning(-90, 40);
    pros::delay(250);
    driving(36, 100, false);
    pros::delay(250);
    turning(15, 40);
    pros::delay(1500);
    indexerShoot(4);
    pros::delay(250);
    stopFlywheel;
    setDrive(-100, -100);
    pros::delay(4000);
    setDrive(0, 0);
    pros::delay(250);
    driving(6, 80, false);
    pros::delay(250);
    turning(45, 40);
    pros::delay(500);
    Controller1.rumble("--..--");
    endgameShoot(true);
    Controller1.rumble("----");
}

void TapeSideEndgame(){

}

void BackUpSkills(){
    spinFlywheel;
    setDrive(-60, -60);
    pros::delay(500);
    setDrive(0, 0);
    pros::delay(1500);
    Intake.move_relative(0.3, pros::E_MOTOR_ENCODER_ROTATIONS);
    pros::delay(1500);
    driving(2.5, 80, false);
    pros::delay(250);
    turning(-12.75, 40);
    pros::delay(750);
    indexerShoot(3);
    pros::delay(250);
    stopFlywheel;
    driving(5, 80, false);
    pros::delay(250);
    turning(45, 40);
    pros::delay(250);
    Controller1.rumble("--..--");
    endgameShoot(true);
    pros::delay(500);
    Controller1.rumble("----");
}