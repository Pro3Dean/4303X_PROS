#include "main.h"

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "4303X Online");
	Controller1.clear();
	Controller1.print(1, 0, "Calibration: In Progress.");
	Inertial.reset();
	pros::Task::delay(5000);
	Controller1.set_text(1, 0, "Calibration: Complete!");
	pros::Task::delay(1000);
	Controller1.clear();

	LeftDrive.set_brake_modes(pros::E_MOTOR_BRAKE_BRAKE);
	RightDrive.set_brake_modes(pros::E_MOTOR_BRAKE_BRAKE);
	Intake.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
	Flywheel.set_brake_mode(pros::E_MOTOR_BRAKE_BRAKE);
	endgameShoot(false);
}
/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {
	endgameShoot(false);
	Flywheel = 0;
	LeftDrive = 0;
	RightDrive = 0;
	Intake = 0;
}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {/*
	if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_X)){
		autonomousPreSet = 0;
		Controller1.clear();
		Controller1.set_text(5, 1, "RollerSide Selected");
	}else if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_X) && Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_B)){
		autonomousPreSet = 1;
		Controller1.clear();
		Controller1.set_text(5, 1, "RollerSideAWP Selected");
	}else if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_Y)){
		autonomousPreSet = 2;
		Controller1.clear();
		Controller1.set_text(5, 1, "TapeSide Selected");
	}else if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_Y) && Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_B)){
		autonomousPreSet = 3;
		Controller1.clear();
		Controller1.set_text(5, 1, "TapeSideAWP Selected");
	}else if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_A)){
		autonomousPreSet = 4;
		Controller1.clear();
		Controller1.set_text(5, 1, "RollerSideEndgame Selected");
	}else if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_B)){
		autonomousPreSet = 5;
		Controller1.clear();
		Controller1.set_text(5, 1, "TapeSideEndgame Selected");
	}else if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_B) && Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_A)){
		autonomousPreSet = 6;
		Controller1.clear();
		Controller1.set_text(5, 1, "BackUpSkills Selected");
	}*/
}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {/*
	if(autonomousPreSet == 0){
		RollerSide();
	}else if(autonomousPreSet == 1){
		RollerSideAWP();
	}else if(autonomousPreSet == 2){
		TapeSide();
	}else if(autonomousPreSet == 3){
		TapeSideAWP();
	}else if(autonomousPreSet == 4){
		RollerSideEndgame();
	}else if(autonomousPreSet == 5){
		TapeSideEndgame();
	}else if(autonomousPreSet == 6){
		BackUpSkills();
	}*/
	turning(90, 40);
}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {
	Controller1.clear();
	while (true) {
		Controller1.print(1, 1, "Flywheel: %f", Flywheel.get_actual_velocity());
		//Tank Drive Controls
		setDriveMotors();
		//Intake Control
		setIntakeMotors();
		//Flywheel Control
		setFlywheelMotors();
		//Pneumatics Control
		setPneumatics();
		pros::delay(10);
	}
}
