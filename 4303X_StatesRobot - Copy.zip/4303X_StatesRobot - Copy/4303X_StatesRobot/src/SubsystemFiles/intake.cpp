#include "main.h"

//Helper Functions
void setIntake(int power){
    Intake = power;
}

//Driver Control Functions
void setIntakeMotors(){
    int intakePower = 127 * (Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_UP) - Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN));
    if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT))
        intakePower = 50;
    else if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT))
        intakePower = -50;
    setIntake(intakePower);
}