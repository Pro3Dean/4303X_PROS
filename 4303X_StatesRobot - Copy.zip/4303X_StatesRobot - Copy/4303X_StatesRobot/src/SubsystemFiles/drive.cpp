#include "main.h"

//Helper Functions
void setDrive(int left, int right){
    LeftDrive = left;
    RightDrive = right;
}

void resetDriveEncoders(){
    LeftDrive.tare_position();
    RightDrive.tare_position();
}

double averageDriverEncoders(){
    return (fabs(FrontLeft.get_position()) +
            fabs(MiddleLeft.get_position()) +
            fabs(BackLeft.get_position()) +
            fabs(FrontRight.get_position()) +
            fabs(MiddleRight.get_position()) +
            fabs(BackRight.get_position())) / 6;
}
//Driver Control Functions
void setDriveMotors(){
    int leftJoystick = Controller1.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
    int rightJoystick = Controller1.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
    if(abs(leftJoystick) < 10)
        leftJoystick = 0;
    if(abs(rightJoystick) < 10)
        rightJoystick = 0;
    setDrive(leftJoystick, rightJoystick);
}

//Autonomous Functions
void driving(float inches, int voltage, bool intakeWhileDrive = false){
    //define direction based on units provided
    int direction = abs(inches) / inches; //1 or -1
    //reset motor encoders
    resetDriveEncoders();
    Inertial.tare();
    //drive until units are reached
    while(averageDriverEncoders() < abs(inches)){
        if(intakeWhileDrive == true)
            Intake = 127;
        else
            Intake = 0;
        setDrive(voltage * direction + Inertial.get_rotation(), voltage * direction - Inertial.get_rotation());
        pros::delay(10);
    }
    //brief brake
    setDrive(-10 * direction, -10 * direction);
    pros::delay(50);
    //set drive to 0
    setDrive(0, 0);
    pros::delay(275);
    Intake = 0;
}

void turning(float degrees, int voltage){
    //define direction based on units provided
    int direction = abs(degrees) / degrees; //1 or -1
    //reset gyro
    Inertial.tare();
    double turnKP = 0.25;
    double turnKD = 0;

    //Calculate
    double error = degrees - (Inertial.get_rotation());
    double derivative;
    double prevError;

    while(fabs(error) > 1){
        error = degrees - Inertial.get_rotation();

        derivative = error - prevError;
        prevError = error;
        double p = error * turnKP;
        double d = derivative * turnKD;

        double vel = p + d;

        FrontLeft = vel * voltage;
        FrontRight = -vel * voltage;
        MiddleLeft = vel * voltage;
        MiddleRight = -vel * voltage;
        BackLeft = vel * voltage;
        BackRight = -vel * voltage;
    }
    FrontLeft = 0;
    FrontRight = 0;
    MiddleLeft = 0;
    MiddleRight = 0;
    BackLeft = 0;
    BackRight = 0;
}

#define PI 3.14159265358979323846
#define fieldscale 1.66548042705
#define SL 5    //distance from tracking center to middle of left wheel
#define SR 5 //distance from tracking center to middle of right wheel
#define SS 7.75 //distance from tracking center to middle of the tracking wheel
#define WheelDiam 2.75 //diameter of all the wheels being used for tracking
#define tpr 360  //Degrees per single encoder rotation

double wheelCircumference = PI * WheelDiam;

double deltaLeft = 0;
double deltaRight = 0;
double deltaBack = 0;
double currentLeft = 0;
double currentRight = 0;
double prevLeft = 0;
double prevRight = 0;
double deltaTheta = 0;
double X = 0;
double Y = 0;
double theta = 0;
double deltaXSide = 0;
double deltaYSide = 0;
double sideChord = 0;
double odomHeading = 0;
double xPos = 0;
double yPos = 0;

void TrackPOS() {
    currentRight = RightWheel.get_position();
    currentLeft = LeftWheel.get_position();

    deltaLeft = ((currentLeft - prevLeft) * wheelCircumference) / tpr;
    deltaRight = ((currentRight - prevRight) * wheelCircumference) / tpr;

    deltaTheta = (deltaRight - deltaLeft) / (SL + SR);

    if(deltaTheta == 0){
        X += deltaLeft * sin(theta);
        Y += deltaLeft * cos(theta);
    }else{
        sideChord = 2 * ((deltaLeft / deltaTheta) + SL) * sin (deltaTheta / 2);
        deltaYSide = sideChord * cos(theta + (deltaTheta/2));
        deltaXSide = sideChord * sin(theta + (deltaTheta/2));

        theta += deltaTheta;
        X += deltaXSide;
        Y += deltaYSide;
    }

    odomHeading = theta * (180/PI);
    xPos = X/12;
    yPos = Y/12;

    prevLeft = currentLeft;
    prevRight = currentRight;
    deltaTheta = 0;
}