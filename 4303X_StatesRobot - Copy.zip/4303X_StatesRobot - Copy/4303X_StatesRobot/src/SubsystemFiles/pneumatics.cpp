#include "main.h"

//Drive Control Functions
void setPneumatics(){
    if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_R1))
        Indexer.set_value(true);
    else
        Indexer.set_value(false);

    if(Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_L2) && Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_R2))
        EndgameLeft.set_value(true);
        EndgameRight.set_value(true);
}

//Autonomous Functions
void indexerShoot(int shootingAmount){
    int shotsDone = 0;
    while(shotsDone <= shootingAmount){
        Indexer.set_value(true);
        pros::delay(250);
        Indexer.set_value(false);
        pros::delay(750);
        shotsDone + 1;
    }
}

void endgameShoot(bool fire = false){
    EndgameLeft.set_value(fire);
    EndgameRight.set_value(fire);
    pros::delay(50);
}