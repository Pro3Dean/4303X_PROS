#include "main.h"

//Helper Functions
void setFlywheel(int power){
    Flywheel = power;
}

//Driver Control Functions
void setFlywheelMotors(){
    int flywheelPower = 100 /*Controller1.get_digital(pros::E_CONTROLLER_DIGITAL_L1)*/;
    setFlywheel(flywheelPower);
}

//Autonomous Functions
void spinFlywheel(double volts = 115){
    setFlywheel(volts);
}

void stopFlywheel(){
    Flywheel = 0;
}
