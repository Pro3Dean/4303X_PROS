#include "main.h"

//Motors
pros::Motor FrontLeft(20, pros::E_MOTOR_GEARSET_18, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor MiddleLeft(15, pros::E_MOTOR_GEARSET_18, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor BackLeft(14, pros::E_MOTOR_GEARSET_18, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor_Group LeftDrive({20, 15, 14});

pros::Motor FrontRight(12, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor MiddleRight(16, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor BackRight(11, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor_Group RightDrive({12, 16, 11});

pros::Motor Flywheel(10, pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor Intake(13, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);
//Pneumatics
pros::ADIDigitalOut Indexer(1, false);
pros::ADIDigitalOut EndgameLeft(2, false);
pros::ADIDigitalOut EndgameRight(3, false);
//Sensors
pros::Imu Inertial(9);
pros::Rotation CenterWheel(2);  //Center tracking wheel (Odom)
pros::Rotation RightWheel(1);   //Right tracking wheel (Odom)
pros::Rotation LeftWheel(19);    //Left tracking wheel (Odom)

//Controller
pros::Controller Controller1(pros::E_CONTROLLER_MASTER);

int autonomousPreSet = 0;