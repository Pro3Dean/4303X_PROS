#include "main.h"

//Helper Functions
void setDrive(int left, int right);
void resetDriveEncoders();
double averageDriverEncoders();

//Driver Control Functions
void setDriveMotors();

//Autonomous Functions
void driving(float inches, int voltage, bool intakeWhileDrive);
void turning(float degrees, int voltage);
void TrackPOS();