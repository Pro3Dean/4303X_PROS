#include "main.h"

//Driver Control Functions
void setFlywheelMotors();

//Autonomous Functions
void spinFlywheel(double RPM);
void stopFlywheel();