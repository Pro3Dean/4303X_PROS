#include "main.h"

//Motors
extern pros::Motor FrontLeft;
extern pros::Motor MiddleLeft;
extern pros::Motor BackLeft;
extern pros::Motor_Group LeftDrive;
extern pros::Motor FrontRight;
extern pros::Motor MiddleRight;
extern pros::Motor BackRight;
extern pros::Motor_Group RightDrive;
extern pros::Motor Flywheel;
extern pros::Motor Intake;
//Pneumatics
extern pros::ADIDigitalOut Indexer;
extern pros::ADIDigitalOut EndgameLeft;
extern pros::ADIDigitalOut EndgameRight;
//Sensors
extern pros::Imu Inertial;
extern pros::Rotation CenterWheel;  //Center tracking wheel (Odom)
extern pros::Rotation RightWheel;   //Right tracking wheel (Odom)
extern pros::Rotation LeftWheel;    //Left tracking wheel (Odom)

//Controller
extern pros::Controller Controller1;

//Autonomous Selection
extern int autonomousPreSet;