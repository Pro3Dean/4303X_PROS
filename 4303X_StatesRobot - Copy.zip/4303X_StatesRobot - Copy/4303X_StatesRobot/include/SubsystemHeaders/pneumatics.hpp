#include "main.h"

//Drive Control Functions
void setPneumatics();

//Autonomous Functions
void indexerShoot(int shootingAmount);
void endgameShoot(bool fire);