#include "main.h"

//Front of Roller
void RollerSide();      //PreSet 0
void RollerSideAWP();       //PreSet 1

//Next To Tape
void TapeSide();        //PreSet 2
void TapeSideAWP();         //PreSet 3

//Skills
void RollerSideEndgame();   //PreSet 4
void TapeSideEndgame();     //PreSet 5
void BackUpSkills();        //PreSet 6